<?php
date_default_timezone_set("Asia/Calcutta");   //India time (GMT+5:30)


return array(
    'appurlVe1'=>'http://localhost/testservers/api/api/ve1',	
);