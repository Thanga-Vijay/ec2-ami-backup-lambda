<?php

namespace App\Http\Controllers\Api\version1;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class AuthControllerVe1 extends Controller
{
    public function test(Request $request)
    {
        try {
            $msg = ["msg" => "Request success"];
            return response()->json(
                ["status" => true, "message" => $msg],
                200
            );
        } catch (\Throwable $th) {
            $msg = ["msg" => "Request failed"];
            return response()->json(
                ["status" => false, "message" => $msg],
                200
            );
        }
        
    }
}
